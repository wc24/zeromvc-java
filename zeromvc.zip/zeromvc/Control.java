package com.lime.zeromvc;

import java.util.*;

/**
 * Created by linming on 14-10-23.
 */
public class Control<TKey>{

    private Map<TKey, List<Class<ICommand>>> pool;


    public Control() {
        pool = new HashMap<TKey, List<Class<ICommand>>>();
    }



    public boolean addListener(TKey type, Class<?> classType) {
        Boolean out = false;
        if (!hasListener(type)) {
            pool.put(type, new ArrayList<Class<ICommand>>());
        }
        if (!hasListener(type, classType)) {
            pool.get(type).add((Class<ICommand>) classType);
            out = true;
        }
        return out;
    }

    public boolean removeListener(TKey type, Class<?> classType) {
        Boolean out = false;
        if (hasListener(type)) {
            out = pool.get(type).remove(classType);
        }
        return out;
    }

    public boolean clearListener(TKey type) {
        Boolean out = false;
        if (hasListener(type)) {
            pool.get(type).clear();
            pool.remove(type);
            out = true;
        }
        return out;
    }

    public boolean hasListener(TKey type) {
        return pool.containsKey(type);
    }

    public boolean hasListener(TKey type, Class<?> classType) {
        if(ICommand.class.isAssignableFrom(classType)){
            return pool.containsKey(type) && pool.get(type).contains(classType);
        }else {
            System.out.println("[LIME] classType must be ICommand subclasses ");
            return false;
        }
    }

    public int notify(TKey type, Object data) {
        int out = 0;
        if (hasListener(type)) {
            for (Class<ICommand> classType : pool.get(type)) {
                ICommand commandInstance;
                try {
                    commandInstance = classType.newInstance();
                    commandInstance.execute(type, data);
                    out++;
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return out;
    }

    public int notify(TKey type) {
        return notify(type, null);
    }
}
