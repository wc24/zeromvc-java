package com.lime.zeromvc;

/**
 * Created by linming on 14-10-22.
 */
public class Proxy extends Observer<ProxyEvent> {
    public Proxy() {
    }

    public void hide() {
        notify(ProxyEvent.HIDE);
    }

    public void update() {
        notify(ProxyEvent.UPDATE);

    }

    public void show() {
        notify(ProxyEvent.SHOW);

    }
}
