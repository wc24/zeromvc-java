package com.lime.zeromvc;

/**
 * Created by linming on 14-10-22.
 */
public abstract class Command implements ICommand {
    private Zero zero;
    private void regist(Zero zero) {
        this.zero = zero;
    }
    public <TProxy extends Proxy> TProxy getProxy(Class<TProxy> proxyClass) {
        return zero.model.getProxy(proxyClass);
    }
}
