package com.lime.zeromvc;


/**
 * Created by linming on 14-10-21.
 */
public class Zero<TCommandKeyEnum> extends Observer<ZeroEvent> {
    public Control<TCommandKeyEnum> control;
    public Model model;
    public View view;
    public Zero() {
        control = new Control();
        model = new Model();
        view = new View();
        //notify(ZeroEvent.CCC);
        addMediator();
        addCommand();
    }

    private void addCommand(TCommandKeyEnum type, Class<?> classType) {
        control.addCommand(type,classType);
    }

    private void addMediator(Proxy proxy ,Mediator mediator) {

    }

}
