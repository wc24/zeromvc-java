package com.lime.zeromvc;

/**
 * Created by linming on 14-10-22.
 */
public interface IMediator {
}
