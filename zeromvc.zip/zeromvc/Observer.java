package com.lime.zeromvc;

import java.util.*;

/**
 * Created by linming on 14-10-22.
 */
public class Observer<TKey> implements IObserver<TKey> {

    private Map<TKey, List<INotifier>> pool;
    private IObserver target;


    public Observer() {
        this.target = this;
        pool = new HashMap<TKey, List<INotifier>>();
    }

    public Observer(IObserver target) {
        this.target = target;
        pool = new HashMap<TKey, List<INotifier>>();
    }

    @Override
    public boolean addListener(TKey type, INotifier notifier) {
        Boolean out = false;
        if (!hasListener(type)) {
            pool.put(type, new ArrayList<INotifier>());
        }
        if (!hasListener(type, notifier)) {
            pool.get(type).add(notifier);
            out = true;
        }
        return out;
    }

    @Override
    public boolean removeListener(TKey type, INotifier notifier) {
        Boolean out = false;
        if (hasListener(type)) {
            out = pool.get(type).remove(notifier);
        }
        return out;
    }

    @Override
    public boolean clearListener(TKey type) {
        Boolean out = false;
        if (hasListener(type)) {
            pool.get(type).clear();
            pool.remove(type);
            out = true;
        }
        return out;
    }

    @Override
    public boolean hasListener(TKey type) {
        return pool.containsKey(type);
    }

    @Override
    public boolean hasListener(TKey type, INotifier notifier) {
        return pool.containsKey(type) && pool.get(type).contains(notifier);
    }

    @Override
    public int notify(TKey type, Object data) {
        if (hasListener((TKey) type)) {
            for (INotifier notifier : pool.get(type)) {
                notifier.execute(target, type, data);
            }
            return pool.get(type).size();
        } else {
            return 0;
        }
    }

    @Override
    public int notify(TKey type) {
        return notify(type, null);
    }
}
