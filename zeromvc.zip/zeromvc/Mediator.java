package com.lime.zeromvc;

/**
 * Created by linming on 14-10-22.
 */
public abstract class Mediator implements INotifier<Proxy,ProxyEvent,Object> {
    private Zero zero;
    private Proxy proxy;
    public Mediator(Proxy proxy){
    }

    private void regist(Zero zero, Proxy proxy) {
        this.zero = zero;
        this.proxy = proxy;
        proxy.addListener(ProxyEvent.SHOW,this);
        proxy.addListener(ProxyEvent.HIDE,this);
    }

    public <TProxy extends Proxy> TProxy getProxy(Class<TProxy> proxyClass) {
        return zero.model.getProxy(proxyClass);
    }

    public void addProxy(Proxy proxy) {
        proxy.addListener(ProxyEvent.UPDATE,this);
    }
    public abstract void update(Proxy proxy);
    public abstract void hide();
    public abstract void show();
    @Override
    public void execute(Proxy proxy, ProxyEvent type, Object content) {
        switch (type) {
            case UPDATE:
                update(proxy);
                break;
            case SHOW:
                show();
                break;
            case HIDE:
                hide();
                break;
        }
    }
}
