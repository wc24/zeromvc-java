package com.lime.zeromvc;

/**
 * Created by linming on 14-10-23.
 */
public interface INotifier<TTarget,TKey,TContent> {
    public void execute(TTarget target ,TKey type, TContent content);
}
