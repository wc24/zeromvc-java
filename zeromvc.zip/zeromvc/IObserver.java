package com.lime.zeromvc;

/**
 * Created by linming on 14-10-22.
 */
public interface IObserver<TKey> {
    public boolean addListener(TKey type, INotifier notifier);

    public boolean removeListener(TKey type, INotifier notifier);

    public boolean hasListener(TKey type, INotifier notifier);

    public boolean clearListener(TKey type);

    public boolean hasListener(TKey type);

    public int notify(TKey type , Object data);

    public int notify(TKey type);

}
