package com.lime.zeromvc;

/**
 * Created by linming on 14-10-22.
 */
public interface ICommand<TKey,TContent>{
    public void execute(TKey type, TContent content);
}
