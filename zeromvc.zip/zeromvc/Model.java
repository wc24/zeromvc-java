package com.lime.zeromvc;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by linming on 14-10-24.
 */
public class Model {
    public Map<Class<Proxy>, Proxy> proxyPool;

    public Model() {
        proxyPool = new HashMap<Class<Proxy>, Proxy>();
    }


    public <TProxy extends Proxy> TProxy getProxy(Class<TProxy> proxyClass) {
        TProxy proxy = null;
        if (proxyPool.containsKey(proxyClass)) {
            proxy = (TProxy) proxyPool.get(proxyClass);
        } else {
            try {
                proxy = (TProxy)proxyClass.newInstance();

                proxyPool.put((Class<Proxy>) proxyClass, proxy);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return proxy;
    }
}
