package com.lime.zeromvc;

/**
 * Created by linming on 14-10-23.
 */
public enum ZeroEvent {

}
